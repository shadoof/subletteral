var stories = {
	"murder": {
		"title" : [
		"On awaiting the trial of a poor girl",
		"having murdered a pastor with a fire iron,",
		"Portsmouth, 1818"
		],
		"tseconds" : 10,
		"seconds" : 18,
		"text" : [
		"To hear (him) preach in a bower,",
		"the loft over the root!",
		"The sear festers, unheeded.",
		"A seam! The horse",
		"is spurred. The nearing is deterred.",
		"The throat is in the threat."
		],
		"text_sublit" : [
		"Or near (her) breach in a power,",
		"she left over the roof!",
		"The scar fosters, unneeded.",
		"A scam! The hearse",
		"is spurned. The hearing is deferred.",
		"The threat is in the throat."
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : [],
	},
	"ars": {
		"title" : [
		"ARS POETICA : On the origins of Collaboration,",
		"On material Difference, On the Giving Up",
		"of one novel for another, On",
		"Paul Virilio’s BUNKER ARCHAEOLOGY"
		],
		"tseconds" : 14,
		"seconds" : 19,
		"text" : [
		"One coded in his hovel. The pairs",
		"adopt a font. Blots and marks change.",
		"Type reads. The path revealed the",
		"(sub)literal différance, and shone in",
		"a word on the crest."
		],
		"text_sublit" : [
		"One ceded in her novel. The pains",
		"adapt a fort. Plots and monks charge.",
		"Typo roads. The oath revealed the",
		"(sub)litoral difference, our shore is",
		"a ward of the coast."
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : [],
	},
	"lascaux": {
		"title" : [
		"In contemplation of the ochre aurochs of",
		"Lascaux: a post-human lament"
		],
		"tseconds" : 9,
		"seconds" : 20,
		"text" : [
		"Our wan beasts inked, in caves,",
		"do bear meaning in codes, deferred.",
		"Birds nesting. A herd, a flock.",
		"We tended and heard. We brew wines",
		"of bone relics in the eon bending."
		],
		"text_sublit" : [
		"Our war boasts irked, on eaves,",
		"to hear moaning is ceded, deterred.",
		"Binds resting. A hero, a flake.",
		"We fended our hoard. My brow wired",
		"to bore relies on the con pending."
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : []
	}
};
