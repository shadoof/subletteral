var stories = {
	"murder": {
		"title" : [
		"On awaiting the trial of a poor girl",
		"having murdered a pastor with a fire iron,",
		"Portsmouth, 1818"
		],
		"tseconds" : 9,
		"seconds" : 18,
		"text" : [
		"To_hear_(him) preach in a bower,",
		"the_loft_over_the_root!",
		"The sear festers, unheeded.",
		"A seam! The horse",
		"is spurred. The nearing is deterred.",
		"The throat is in the threat."
		],
		"text_sublit" : [
		"Or_near_(her) breach in a power,",
		"she_left_over_the_roof!",
		"The scar fosters, unneeded.",
		"A scam! The hearse",
		"is spurned. The hearing is deferred.",
		"The threat is in the throat."
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : [],
	},
	"ars": {
		"title" : [
		"ars poetica:  on the origins of collaboration,",
		"on material difference, on the giving up of",
		"one novel for another, on Paul Virilio’s Bunker Anatom"
		],
		"tseconds" : 12,
		"seconds" : 18,
		"text" : [
		"One coded in his hovel. The pairs",
		"adopt a font. Blots and marks change.",
		"Type reads. The path revealed the",
		"(sub)literal differance, and shone in",
		"a word on the crest."
		],
		"text_sublit" : [
		"One ceded in her novel. The pains",
		"adapt a fort. Plots and monks charge.",
		"Typo roads. The oath revealed the",
		"(sub)litoral difference, our shore is",
		"a ward of the coast."
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : [],
	},
	"lascaux": {
		"title" : [
		"In contemplation of the ochre aurochs of",
		"Lascaux: a post-human lament"
		],
		"tseconds" : 9,
		"seconds" : 20,
		"text" : [
		"Our wan beasts inked, in_caves,",
		"do_bear meaning in_codes, deferred.",
		"Birds_nesting. A herd, a flock.",
		"We tended and_heard. We_brew_wines",
		"of_bone_relics in_the_eon_bending."
		],
		"text_sublit" : [
		"Our war boasts irked, on_eaves,",
		"to_hear moaning is_ceded, deterred.",
		"Binds_resting. A hero, a flake.",
		"We fended our_hoard. My_brow_wired",
		"to_bore_relies on_the_con_pending."
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : []
	}
};