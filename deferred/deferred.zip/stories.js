var stories = {
	"deferred": {
		"title" : [
		],
		"tseconds" : 7,
		"seconds" : 20,
		"text" : [
			"deferred  lest  meaning",
			"hoard solidify / unfold",
			"ever    new     literal",
			"intensity / gene hearse",
			"heroin   /  frail  rift",
			"lesson  / read it ceded",
			"inferred   /   inferred",
			"ceded it read /  lesson",
			"rift  frail  /   heroin",
			"hearse gene / intensity",
			"literal    new     ever",
			"unfold / solidify hoard",
			"meaning  lest  deferred"
		],
		"text_sublit" : [
			"deterred  lost  moaning",
			"heard solidity / untold",
			"over    now     litoral",
			"intensify / gone hoarse",
			"herein   /  trail  riff",
			"lessen  / road if coded",
			"interred   /   interred",
			"coded if road /  lessen",
			"riff  trail  /   herein",
			"hoarse gone / intensify",
			"litoral    now     over",
			"untold / solidity heard",
			"moaning  lost  deterred"
		],
		"tokens" : [],
		"tokens_sublit" : [],
		"tokens_normalized" : [],
		"tokens_normalized_sublit" : []
	}
};
